package com.stox.workbench;

import com.stox.util.Async;
import com.stox.widget.Icon;

import javafx.application.Application;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class WorkbenchFxApplication extends Application {

	private Workbench workbench;
	
	@Override
	public void start(Stage stage) throws Exception {
		workbench = new Workbench(stage);
		workbench.start();
	}
	
	@Override
	public void stop() throws Exception {
		workbench.stop();
		super.stop();
		Async.shutdown();
	}

	public static void main(String[] args) {
		Font.loadFont(Icon.class.getClassLoader().getResource(Icon.PATH).toExternalForm(), 10);
		Application.launch(WorkbenchFxApplication.class, args);
	}

}
