package com.stox.widget.menu;

import java.util.function.BiConsumer;

import javafx.scene.control.ContextMenu;

public interface MenuProvider extends BiConsumer<ContextMenu, Object>{

	
	
}
