package com.stox.auto;

import javafx.scene.Node;

public class AutoFormField extends AutoVBox{

	public AutoFormField() {
		super();
	}

	public AutoFormField(double spacing, Node... children) {
		super(spacing, children);
	}

	public AutoFormField(double spacing) {
		super(spacing);
	}

	public AutoFormField(Node... children) {
		super(children);
	}
	
	
	
}
