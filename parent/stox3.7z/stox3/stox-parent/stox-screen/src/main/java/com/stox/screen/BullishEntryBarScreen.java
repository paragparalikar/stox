package com.stox.screen;

import java.util.List;

import com.stox.core.model.Bar;
import com.stox.screen.BullishEntryBarScreen.Config;

public class BullishEntryBarScreen implements Screen<Config> {

	public static class Config {

	}

	@Override
	public String getCode() {
		return "screen-bullish-bar-entry";
	}

	@Override
	public String getName() {
		return "Bullish Entry Bar";
	}

	@Override
	public ScreenType getScreenType() {
		return ScreenType.BULLISH;
	}

	@Override
	public Config buildDefaultConfig() {
		return new Config();
	}

	@Override
	public int getMinBarCount(Config config) {
		return 3;
	}

	@Override
	public boolean isMatch(List<Bar> bars, Config config) {
		final Bar bar = bars.get(0);
		final Bar one = bars.get(1);
		final Bar two = bars.get(2);
		return bar.getClose() >= one.getHigh() && one.getClose() < two.getHigh();
	}

}
