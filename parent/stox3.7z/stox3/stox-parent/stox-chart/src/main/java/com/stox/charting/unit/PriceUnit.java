package com.stox.charting.unit;

import com.stox.core.model.Bar;

public interface PriceUnit extends Unit<Bar> {


}
