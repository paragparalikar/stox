package com.stox.charting.event;

import javafx.event.Event;
import javafx.event.EventType;

public class BarDataLoadingEvent extends Event{
	private static final long serialVersionUID = -2795898858635016113L;
	
	public static final EventType<BarDataLoadingEvent> TYPE = new EventType<>("BarDataLoadingEvent");

	private final boolean loading;

	public BarDataLoadingEvent(final boolean loading) {
		super(TYPE);
		this.loading = loading;
	}
	
	public boolean isLoading() {
		return loading;
	}

}
