package com.stox.charting.drawing.icon;

import com.stox.charting.axis.horizontal.XAxis;
import com.stox.charting.axis.vertical.YAxis;
import com.stox.charting.drawing.AbstractDrawing;

import javafx.scene.Node;

public class Demand extends AbstractDrawing{

	@Override
	public int getDrawingId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void layoutChartChildren(XAxis xAxis, YAxis yAxis) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String format() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void parse(String text) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Node getNode() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(XAxis xAxis, YAxis yAxis) {
		// TODO Auto-generated method stub
		
	}


}
