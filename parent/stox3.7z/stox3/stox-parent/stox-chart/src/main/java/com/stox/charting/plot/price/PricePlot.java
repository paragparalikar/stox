package com.stox.charting.plot.price;

import java.util.List;

import com.stox.charting.Configuration;
import com.stox.charting.axis.horizontal.XAxis;
import com.stox.charting.event.BarDataLoadingEvent;
import com.stox.charting.plot.Plot;
import com.stox.charting.plot.Underlay;
import com.stox.charting.unit.Unit;
import com.stox.core.model.Bar;
import com.stox.core.model.BarSpan;
import com.stox.core.model.Scrip;
import com.stox.core.repository.BarRepository;
import com.stox.util.Async;
import com.stox.widget.Ui;

import lombok.Getter;
import lombok.Setter;

public class PricePlot extends Plot<Bar> {

	@Getter
	@Setter
	private Scrip scrip;
	private boolean loading, fullyLoaded;

	public PricePlot(final Configuration configuration) {
		super(configuration);
	}

	public void load(final BarSpan barSpan, final long to, final XAxis xAxis) {
		final List<Bar> models = getModels();
		if (null != scrip && null != barSpan && !loading && !fullyLoaded && xAxis.getEndIndex() > getModels().size()) {
			loading = true;
			Ui.fx(() -> fireEvent(new BarDataLoadingEvent(loading)));
			Async.execute(() -> {
				try {
					final long effectiveTo = models.isEmpty() ? (0 >= to ? System.currentTimeMillis() : to) : models.get(models.size() - 1).getDate() - barSpan.getMillis();
					final long effectiveFrom = effectiveTo - 400 * barSpan.getMillis();
					final List<Bar> bars = BarRepository.getInstance().find(scrip.getIsin(), barSpan, effectiveFrom, effectiveTo);
					if (!(fullyLoaded = bars.isEmpty())) {
						accept(bars);
					}
				} finally {
					loading = false;
					Ui.fx(() -> fireEvent(new BarDataLoadingEvent(loading)));
				}
				load(barSpan, to, xAxis);
			});
		}
	}

	protected void accept(List<Bar> bars) {
		synchronized(getModels()){
			getModels().addAll(bars);
		}
	}

	@Override
	public void reset() {
		super.reset();
		fullyLoaded = false;
	}

	@Override
	public Unit<Bar> buildUnit() {
		return null;
	}

	@Override
	public void showIndexInfo(int index) {

	}

	@Override
	public double getMax(Bar bar) {
		return bar.getHigh();
	}

	@Override
	public double getMin(Bar bar) {
		return bar.getLow();
	}

	@Override
	public Underlay getUnderlay() {
		return Underlay.PRICE;
	}

}
