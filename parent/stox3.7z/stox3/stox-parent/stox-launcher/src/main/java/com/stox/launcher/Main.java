package com.stox.launcher;

import com.stox.workbench.WorkbenchFxApplication;

public class Main {

	public static void main(String[] args) {
		WorkbenchFxApplication.main(args);
	}
	
}
