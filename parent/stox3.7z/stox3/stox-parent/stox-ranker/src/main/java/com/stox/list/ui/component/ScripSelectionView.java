package com.stox.list.ui.component;

import java.util.List;

import com.stox.core.model.Scrip;
import com.stox.core.ui.filter.scrip.ScripFilter;
import com.stox.list.ui.RankerModuleView;
import com.stox.ui.fx.fluent.scene.control.FluentButton;
import com.stox.ui.fx.fluent.scene.layout.FluentHBox;
import com.stox.widget.Icon;
import com.stox.widget.Spacer;

public class ScripSelectionView {

	private final RankerModuleView rankerModuleView;
	private final ScripFilter scripFilter = new ScripFilter();
	private final FluentButton previousButton = new FluentButton(Icon.LONG_ARROW_LEFT).classes("primary", "icon").onAction(e -> previous());
	private final FluentButton nextButton = new FluentButton(Icon.LONG_ARROW_RIGHT).classes("primary", "icon").onAction(e -> next());
	private final FluentHBox buttonBar = new FluentHBox(previousButton, new Spacer(),nextButton).classes("padded");
	
	public ScripSelectionView(RankerModuleView rankerModuleView) {
		this.rankerModuleView = rankerModuleView;
	}
	
	public void start(){
		rankerModuleView.content(scripFilter).bottom(buttonBar);
	}
	
	private void stop(){
		rankerModuleView.content(null).bottom(null);
	}
	
	private void next(){
		stop();
		final List<Scrip> scrips = rankerModuleView.getState().getScrips(); 
		scrips.clear();
		scrips.addAll(scripFilter.get());
		
		final RankerResultView rankerResultView = new RankerResultView(rankerModuleView);
		rankerResultView.start();
	}
	
	private void previous(){
		stop();
		final RankerConfigView rankerConfigView = new RankerConfigView(rankerModuleView);
		rankerConfigView.start();
	}
	
}
